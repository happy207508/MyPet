from django.apps import AppConfig


class AnimalsConfig(AppConfig):
    name = 'animals'
